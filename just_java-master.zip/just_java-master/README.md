# just_java
Coffee ordering application built for Android OS in conjunction with Udacity.
